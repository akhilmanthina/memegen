
public class MemeValues {
	public String t0;
	public String t1;
	public boolean valuesFound;
	
	public MemeValues (String t0, String t1, boolean vf) {
		this.t0 = t0;
		this.t1 = t1;
		valuesFound = vf;
	}
	
	public MemeValues () {
		this.t0 = "";
		this.t1 = "";
		valuesFound = false;
	}
	
}
